package com.example.apgartrack

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun validaListaDeUtentes() {
        assertEquals(4, utentes.size)
        assertEquals(listOf(1, 2, 2, 3), utentes.map { it.avaliacoes.size })
    }

    @Test
    fun avaliacoesEstaoEmOrdemCrescente() {
        assertEquals(listOf(1, 5, 10), utentes[3].avaliacoes.map { it.minuto })
    }
}
