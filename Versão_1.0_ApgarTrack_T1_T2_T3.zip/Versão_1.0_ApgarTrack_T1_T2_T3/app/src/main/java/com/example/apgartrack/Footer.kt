package com.example.apgartrack

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

enum class Ecra { Home, Utentes }

@Composable
fun Footer(ecraAtual: Ecra, onSelecionar: (Ecra) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AppBlue)
            .navigationBarsPadding()
    ) {
        ItemFooter("⌂\nHome", Ecra.Home, ecraAtual, onSelecionar, Modifier.weight(1f))

        // Tarefa 3 - Lista de utentes (Inicio -> Botão Utentes footer)
        ItemFooter("♙\nUtentes", Ecra.Utentes, ecraAtual, onSelecionar, Modifier.weight(1f))
        // Tarefa 3 - Lista de utentes (Final -> Botão Utentes footer)
    }
}

// Criacao de clicaveis no footer (botão Home e Utentes-Tarefa 3)
@Composable
private fun ItemFooter(
    texto: String,
    ecra: Ecra,
    atual: Ecra,
    onSelecionar: (Ecra) -> Unit,
    modifier: Modifier
) {
    Text(
        text = texto,
        modifier = modifier
            .clickable { onSelecionar(ecra) }
            .padding(vertical = 10.dp),
        color = Color.White,
        fontWeight = if (ecra == atual) FontWeight.Bold else FontWeight.Normal,
        textAlign = TextAlign.Center
    )
}
