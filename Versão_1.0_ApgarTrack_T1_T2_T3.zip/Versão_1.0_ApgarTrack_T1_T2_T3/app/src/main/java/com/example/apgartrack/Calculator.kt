package com.example.apgartrack

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
@Preview
fun Calculator() {
    val nomes = listOf(
        "Frequência cardíaca",
        "Esforço respiratório",
        "Tónus muscular",
        "Resposta a estímulos",
        "Cor da pele"
    )
    var valores = remember { mutableStateListOf(-1,-1,-1,-1,-1) }
    var resultado = remember { mutableIntStateOf(0) }
    var minuto = remember { mutableStateOf(1) }

    fun nextMinute() {
        if (minuto.value == 1) {
            minuto.value = 5
        } else if (minuto.value == 5) {
            minuto.value = 10
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("Índice Apgar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Simulação da calculadora", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))

            // Tarefa 1 - alteração do código para criar os botões
            nomes.forEachIndexed { index, nome ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(nome, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (0..2).forEach { valor ->
                            Button(
                                onClick = {
                                    valores[index] = valor
                                    resultado.value = valores.filter { it > -1 }.sum()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (valores[index] == valor)
                                        AppBlue else Color(0xFFEAF2FF)
                                ),
                                modifier = Modifier
                            ) {
                                Text(
                                    valor.toString(),
                                    modifier = Modifier
                                        .padding(vertical = 10.dp),
                                    color = if (valores[index] == valor)
                                        Color.White else Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
            // Fim da tarefa 1

            Spacer(Modifier.height(12.dp))

            // Tarefa 1 - Resultado e submeter (visual)
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Resultado: ${if (valores.all { it > -1 }) resultado.value else "-"}/10",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        // Faz aqui o código do botão
                        if (avaliacoesFeitas.size < 3) {
                            avaliacoesFeitas.add(avaliacao(minuto = minuto.value, valores = valores))
                            valores.fill(-1)
                            resultado.value = 0
                            nextMinute() // Isto adiciona ao minuto guardado na calculadora
                        }
                    },
                    modifier = Modifier,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AppBlue
                    ),
                    enabled = (valores.all { it > -1 })
                ) {
                    Text(
                        "Submeter",
                    )
                }

                // Tarefa - Cenário 2: resultados pequenos + comparação, por baixo do botão
                ResultadosCalculadora()
            }
            // Fim da tarefa 1
        }
    }
}
