package com.example.apgartrack

data class Parametro(val nome: String, val valor: Int)

// Estruturas de dados usadas nas imagens: parâmetros, avaliações e utentes
data class Avaliacao(
    val minuto: Int,
    val parametros: List<Parametro>
) {
    val total = parametros.sumOf { it.valor }
}

data class Utente(
    val nome: String,
    val numero: String,
    val avaliacoes: MutableList<Avaliacao>
)

public fun avaliacao(minuto: Int, valores: List<Int>) = Avaliacao(
    minuto = minuto,
    parametros = listOf(
        Parametro("Frequência cardíaca", valores[0]),
        Parametro("Esforço respiratório", valores[1]),
        Parametro("Tónus muscular", valores[2]),
        Parametro("Resposta a estímulos", valores[3]),
        Parametro("Cor da pele", valores[4])
    )
)

//Tarefa 3 - Inicio -> Lista de utentes estática para simulação
val utentes = mutableListOf(
    Utente(
        nome = "Bebé A",
        numero = "100001",
        avaliacoes = mutableListOf(avaliacao(1, listOf(1, 0, 1, 0, 1)))
    ),
    Utente(
        nome = "Bebé B",
        numero = "100002",
        avaliacoes = mutableListOf(
            avaliacao(1, listOf(1, 1, 1, 1, 1)),
            avaliacao(5, listOf(2, 1, 1, 1, 1))
        )
    ),
    Utente(
        nome = "Bebé C",
        numero = "100003",
        avaliacoes = mutableListOf(
            avaliacao(1, listOf(1, 1, 1, 1, 0)),
            avaliacao(5, listOf(2, 2, 1, 2, 1))
        )
    ),
    Utente(
        nome = "Bebé D",
        numero = "100004",
        avaliacoes = mutableListOf(
            avaliacao(1, listOf(0, 0, 1, 0, 1)),
            avaliacao(5, listOf(1, 1, 1, 1, 1)),
            avaliacao(10, listOf(2, 2, 2, 2, 1))
        )
    )
)
//Tarefa 3 - Fim -> Lista de utentes estática para simulação


// Estruturas de dados usadas nas imagens: parâmetros, avaliações e utentes
fun categoria(total: Int) = when {
    total >= 7 -> "Normal"
    total >= 4 -> "Moderado"
    else -> "Crítico"
}
