package com.example.apgartrack

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Lista das avaliações já submetidas nesta sessão da calculadora (1º, 5º, 10º minuto)
val avaliacoesFeitas = mutableStateListOf<Avaliacao>()

fun corResultado(total: Int) = when {
    total >= 7 -> Color(0xFF2E7D32)
    total >= 4 -> Color(0xFFF9A825)
    else -> Color(0xFFC62828)
}

@Composable
fun ResultadosCalculadora() {
    Column {
        // Mostrar o resultado de cada minuto já submetido
        avaliacoesFeitas.forEach { avaliacao ->
            Text(
                "${avaliacao.minuto}º minuto: ${avaliacao.total}/10 - ${categoria(avaliacao.total)}",
                fontSize = 12.sp,
                color = corResultado(avaliacao.total)
            )
        }

        // Comparar cada teste com o teste anterior (1º com 5º, e 5º com 10º)
        avaliacoesFeitas.forEachIndexed { index, atual ->
            if (index > 0) {
                val anterior = avaliacoesFeitas[index - 1]
                val diferenca = atual.total - anterior.total

                val texto = if (diferenca > 0) {
                    "Entre o ${anterior.minuto}º e o ${atual.minuto}º minuto a pontuação aumentou (melhoria)."
                } else if (diferenca < 0) {
                    "Entre o ${anterior.minuto}º e o ${atual.minuto}º minuto a pontuação diminuiu (agravamento)."
                } else {
                    "Entre o ${anterior.minuto}º e o ${atual.minuto}º minuto a pontuação manteve-se (estabilidade)."
                }

                Text(texto, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Conclusão final, depois do teste do 10º minuto
        if (avaliacoesFeitas.size == 3) {
            val primeiro = avaliacoesFeitas[0]
            val ultimo = avaliacoesFeitas[2]
            val diferencaTotal = ultimo.total - primeiro.total

            val conclusao = if (diferencaTotal > 0) {
                "Conclusão: o bebé melhorou do 1º para o 10º minuto."
            } else if (diferencaTotal < 0) {
                "Conclusão: o bebé agravou do 1º para o 10º minuto."
            } else {
                "Conclusão: o estado do bebé manteve-se estável do 1º para o 10º minuto."
            }

            Text(
                conclusao,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = corResultado(ultimo.total)
            )
        }
    }
}
