package com.example.apgartrack

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AppBlue = Color(0xFF0D6EFD)
private val Fundo = Color(0xFFF4F7FB)

@Composable
fun ApgarScreen() {
    var ecra by remember { mutableStateOf(Ecra.Home) }
    var utenteSelecionado by remember { mutableStateOf<Utente?>(null) }
    var avaliacaoSelecionada by remember { mutableStateOf<Avaliacao?>(null) }

    Scaffold(
        topBar = { Header() },
        bottomBar = {
            Footer(ecra) {
                ecra = it
                utenteSelecionado = null
                avaliacaoSelecionada = null
            }
        }
    ) { padding ->
        when {
            avaliacaoSelecionada != null -> DetalheAvaliacao(
                avaliacao = avaliacaoSelecionada!!,
                modifier = Modifier.padding(padding),
                onVoltar = { avaliacaoSelecionada = null }
            )
            utenteSelecionado != null -> RegistosUtente(
                utente = utenteSelecionado!!,
                modifier = Modifier.padding(padding),
                onAvaliacao = { avaliacaoSelecionada = it },
                onVoltar = { utenteSelecionado = null }
            )
            ecra == Ecra.Home -> Home(
                modifier = Modifier.padding(padding)
            )
            else -> ListaUtentes(
                modifier = Modifier.padding(padding),
                onUtente = { utenteSelecionado = it }
            )
        }
    }
}

@Composable
private fun Home(modifier: Modifier) {
    Conteudo(modifier) {
        item {
            // Tarefa 3 - Lista de utentes (Inicio -> Barra de pesquisa)
            Cartao {
                Text("Utente", fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .height(56.dp)
                        .border(
                            width = 2.dp,
                            color = AppBlue,
                            shape = RoundedCornerShape(4.dp)
                        )
                ) {
                    Text(
                        "Pesquise por nome/nº utente",
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(horizontal = 14.dp),
                        color = AppBlue,
                        fontSize = 14.sp
                    )
                }
            }
        }
        // Tarefa 3 - Lista de utentes (Fim -> Barra de pesquisa)

        item { Calculator() }
    }
}

// Tarefa 3 - Início-> ecrã clicável da lista de utentes do dia
@Composable
private fun ListaUtentes(modifier: Modifier, onUtente: (Utente) -> Unit) {
    Conteudo(modifier) {
        item {
            Text("Lista de utentes do dia", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        utentes.forEach { utente ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onUtente(utente) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(utente.nome, fontWeight = FontWeight.Bold)
                        Text("N.º ${utente.numero}", fontSize = 17.sp)
                        Text(
                            "${utente.avaliacoes.size} ${if (utente.avaliacoes.size == 1) "avaliação" else "avaliações"}",
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
// Tarefa 3 - Fim: ecrã clicável da lista de utentes do dia

// Tarefa 3 - Inicio: Ecrã dos registos do utente selecionado, com avaliações ordenadas e clicáveis.
@Composable
private fun RegistosUtente(
    utente: Utente,
    modifier: Modifier,
    onAvaliacao: (Avaliacao) -> Unit,
    onVoltar: () -> Unit
) {
    Conteudo(modifier) {
        item {
            Button(
                onClick = onVoltar,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppBlue
                )
            ) {
                Text("Voltar aos utentes")
            }
        }
        item {
            Text(utente.nome, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("N.º ${utente.numero}", color = Color.Gray)
            Text("Avaliações por ordem crescente", color = Color.Gray)
        }
        utente.avaliacoes.sortedBy { it.minuto }.forEach { avaliacao ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAvaliacao(avaliacao) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${avaliacao.minuto}.º minuto",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text("${avaliacao.total}/10", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(
                            categoria(avaliacao.total),
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 18.dp),
                            color = corCategoria(avaliacao.total)
                        )
                    }
                }
            }
        }
    }
}
// Tarefa 3 - Fim: Ecrã dos registos do utente selecionado, com avaliações ordenadas e clicáveis.

// Tarefa 3 - Inicio: Ecrã das avaliações dos utentes, já na lista de utentes e clicáveis.
@Composable
private fun DetalheAvaliacao(
    avaliacao: Avaliacao,
    modifier: Modifier,
    onVoltar: () -> Unit
) {
    Conteudo(modifier) {
        item {
            Button(
                onClick = onVoltar,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppBlue
                )
            ) {
                Text("Voltar às avaliações")
            }
        }
        item {
            Cartao {
                Text(
                    "Avaliação do ${avaliacao.minuto}.º minuto",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${avaliacao.total}/10 — ${categoria(avaliacao.total)}",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = corCategoria(avaliacao.total)
                )
            }
        }
        item {
            Cartao {
                Text("Parâmetros", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                avaliacao.parametros.forEach { parametro ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(parametro.nome, modifier = Modifier.weight(1f))
                        Text("${parametro.valor}/2", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
// Tarefa 3 - Fim: Ecrã das avaliações dos utentes, já na lista de utentes e clicáveis.

@Composable
private fun Conteudo(
    modifier: Modifier,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Fundo)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun Cartao(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

private fun corCategoria(total: Int) = when {
    total >= 7 -> Color(0xFF2E7D32)
    total >= 4 -> Color(0xFFF9A825)
    else -> Color(0xFFC62828)
}
